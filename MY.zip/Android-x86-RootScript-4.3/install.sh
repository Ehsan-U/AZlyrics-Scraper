#!/bin/sh
clear
echo This script can run in the root shell of Android x86 or from another Linux OS.
echo "Are you running on the Alt+F1 android shell? (Y/N): "
read type

if [ "$type" = "n" ]; then
	echo This script needs root. Enter your password to continue:
	sudo sh ./script/install.sh
elif [ "$type" = "N" ]; then
	echo This script needs root. Enter your password to continue:
	sudo sh ./script/install.sh
else
	echo "OK, you're in the Android shell. You should already be root. Testing that:"
	if [[ "$(id -u)" = *"uid=0(root)"* ]]; then
		echo "We're running as root, good. Preparing to start root process..."
      echo "Press enter to start installation script"
		read null
		sh ./script/install-device.sh
	else
		echo "Not good, this shell isn't root. You have to run this in the root shell [Alt+F1] or in another Linux OS (read the thread)"
		echo "Kicking back to command line"
		exit
	fi
fi

