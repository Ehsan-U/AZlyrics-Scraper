#!/bin/sh
clear
echo "-----------------------------"
echo "Root script for Android 4.3"
echo "    By Quinny899 @ XDA"
echo "  Root by Chainfire @ XDA"
echo "-----------------------------"
read -p "Enter the partion Android is installed to (eg. /dev/sda1): " partition
read -p "Enter the name of the root folder for Android x86 (default is 'android-4.3-test'): " folder
echo "Installing to: " "$partition""/""$folder""/"
read -p "Press enter to continue installation" null
clear
echo "Installing to" "$partition""/""$folder""/"
mkdir /tmpmnt
echo "Mounting..."
mount "$partition" /tmpmnt
echo "Removing old files..."
rm -r -f /tmpmnt/"$folder"/system/bin/.ext
rm -f /tmpmnt/"$folder"/system/bin/.ext/.su
rm -f /tmpmnt/"$folder"/system/xbin/daemonsu
rm -f /tmpmnt/"$folder"/system/xbin/su
rm -f /tmpmnt/"$folder"/system/etc/init.sh
rm -f /tmpmnt/"$folder"/system/app/Superuser.apk
echo "Copying files..."
mkdir /tmpmnt/"$folder"/system/bin/.ext
cp system/bin/.ext/.su /tmpmnt/"$folder"/system/bin/.ext/
cp system/xbin/su /tmpmnt/"$folder"/system/xbin/
cp system/xbin/daemonsu /tmpmnt/"$folder"/system/xbin/
cp system/app/Superuser.apk /tmpmnt/"$folder"/system/app/
cp system/etc/init.sh /tmpmnt/"$folder"/system/etc/ 
echo "Setting permissions..."
chmod 06755 /tmpmnt/"$folder"/system/xbin/su
chmod 06755 /tmpmnt/"$folder"/system/xbin/daemonsu
chmod 06755 /tmpmnt/"$folder"/system/bin/.ext/.su
chmod 777 /tmpmnt/"$folder"/system/bin/.ext
chmod 755 /tmpmnt/"$folder"/system/etc/init.sh
echo "Cleaning up..."
umount "$partition"
rm -r /tmpmnt
echo ""
echo ""
echo "Finished. Returning to command line."
